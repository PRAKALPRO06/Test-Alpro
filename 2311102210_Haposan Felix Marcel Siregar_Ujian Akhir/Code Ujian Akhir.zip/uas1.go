package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func identitas() {
	fmt.Println("=================================")
	fmt.Println("NIM: 2311102210")
	fmt.Println("Nama:Haposan Felix Marcel Siregar")
	fmt.Println("Kelas: IF-11-06")
	fmt.Println("=================================")
}	

func main() {
	identitas()
	//Fungsi ini  untuk membaca input dari user
	scanner := bufio.NewScanner(os.Stdin)
	fmt.Println("Masukkan elemen baris pertama (pisahkan dengan spasi):")
	scanner.Scan()
	line1 := strings.Fields(scanner.Text())

	fmt.Println("Masukkan elemen baris kedua (pisahkan dengan spasi):")
	scanner.Scan()
	line2 := strings.Fields(scanner.Text())

	// Konversi input ke integer dan buang elemen duplikat
	set1_2311102210 := toUniqueSet(line1)
	set2 := toUniqueSet(line2)

	// Cari irisan dari kedua himpunan
	intersection := findIntersection(set1_2311102210, set2)

	// Tampilkan hasil
	fmt.Println("Irisan kedua himpunan adalah:", intersection)
}

func toUniqueSet(elements []string) map[int]bool {
	set := make(map[int]bool)
	for _, el := range elements {
		num, err := strconv.Atoi(el)
		if err == nil {
			set[num] = true
		}
	}
	return set
}

func findIntersection(set1_2311102210, set2 map[int]bool) []int {
	intersection := []int{}
	for num := range set1_2311102210 {
		if set2[num] {
			intersection = append(intersection, num)
		}
	}
	return intersection
}
