package main

import (
	"fmt"
	"strings"
)

const nProv = 34

type NamaProv [nProv]string
type PopProv [nProv]int
type TumbuhProv [nProv]float64

// Fungsi untuk input data
func InputData(prov *NamaProv, pop *PopProv, tumbuh *TumbuhProv) {
	for i := 0; i < nProv; i++ {
		fmt.Printf("Masukkan data untuk provinsi %d (format: nama populasi pertumbuhan): ", i+1)
		var nama string
		var populasi int
		var pertumbuhan float64
		fmt.Scan(&nama, &populasi, &pertumbuhan)
		prov[i] = nama
		pop[i] = populasi
		tumbuh[i] = pertumbuhan
	}
}

// Fungsi untuk mencari provinsi dengan pertumbuhan penduduk tercepat
func ProvinsiTercepat(tumbuh TumbuhProv) int {
	maxIdx := 0
	for i := 1; i < nProv; i++ {
		if tumbuh[i] > tumbuh[maxIdx] {
			maxIdx = i
		}
	}
	return maxIdx
}

// Fungsi untuk menghitung prediksi jumlah penduduk
func Prediksi(prov NamaProv, pop PopProv, tumbuh TumbuhProv) {
	fmt.Println("Provinsi dengan prediksi populasi tahun depan (pertumbuhan di atas 2%):")
	for i := 0; i < nProv; i++ {
		if tumbuh[i] > 0.02 {
			prediksiPop := float64(pop[i]) * (1 + tumbuh[i])
			fmt.Printf("%s: %.0f\n", prov[i], prediksiPop)
		}
	}
}

// Fungsi untuk mencari indeks provinsi berdasarkan nama
func IndeksProvinsi(prov NamaProv, nama string) int {
	for i := 0; i < nProv; i++ {
		if strings.EqualFold(prov[i], nama) {
			return i
		}
	}
	return -1
}

func main() {
	var prov_2311102210 NamaProv
	var pop PopProv
	var tumbuh TumbuhProv

	// Input data provinsi
	InputData(&prov_2311102210, &pop, &tumbuh)

	// Menentukan provinsi dengan pertumbuhan tercepat
	tercepatIdx := ProvinsiTercepat(tumbuh)
	fmt.Printf("Provinsi dengan pertumbuhan tercepat: %s\n", prov_2311102210[tercepatIdx])

	// Input nama provinsi untuk dicari
	var cariNama string
	fmt.Print("Masukkan nama provinsi yang ingin dicari: ")
	fmt.Scan(&cariNama)

	// Mencari indeks provinsi berdasarkan nama
	idxProvinsi := IndeksProvinsi(prov_2311102210, cariNama)
	fmt.Printf("Indeks provinsi %s: %d\n", cariNama, idxProvinsi)

	// Menampilkan prediksi populasi provinsi dengan pertumbuhan di atas 2%
	Prediksi(prov_2311102210, pop, tumbuh)
}
