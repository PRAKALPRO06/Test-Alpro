package main

import (
	"fmt"
	"sort"
)

func main() {
	const MaxData = 1000000 // Maksimal data_2311102210 yang diperbolehkan
	var data_2311102210 []int          // Array dinamis untuk menyimpan data_2311102210
	var input int

	for {
		fmt.Scan(&input)
		if input == -5313541 { // Marker akhir input
			break
		} else if input == 0 { // Ketika menemukan 0, hitung median
			if len(data_2311102210) == 0 {
				fmt.Println("Tidak ada data_2311102210 untuk dihitung median.")
			} else {
				sort.Ints(data_2311102210) // Urutkan data_2311102210 menggunakan fungsi bawaan Go
				median := calculateMedian(data_2311102210)
				fmt.Println(median)
			}
		} else { // Tambahkan data_2311102210 ke array
			data_2311102210 = append(data_2311102210, input)
		}
	}
}

// Fungsi untuk menghitung median
func calculateMedian(arr []int) int {
	n := len(arr)
	if n%2 == 1 { // Jika jumlah data_2311102210 ganjil
		return arr[n/2]
	}
	// Jika jumlah data_2311102210 genap, hitung rerata dua nilai tengah dan bulatkan ke bawah
	return (arr[n/2-1] + arr[n/2]) / 2
}
