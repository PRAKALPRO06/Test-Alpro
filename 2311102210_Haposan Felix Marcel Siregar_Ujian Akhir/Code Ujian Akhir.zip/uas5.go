package main

import "fmt"

// Konstanta jumlah maksimal partai
const NMAX = 1000000

// Struktur partai
type Partai struct {
	Nama_2311102210  int // Nama_2311102210 partai
	Suara int // Jumlah suara yang diperoleh
}

// Tipe array partai
type tabPartai [NMAX]Partai

func identitas() {
	fmt.Println("=================================")
	fmt.Println("NIM: 2311102210")
	fmt.Println("Nama:Haposan Felix Marcel Siregar")
	fmt.Println("Kelas: IF-11-06")
	fmt.Println("=================================")
}	

func main() {
	identitas()
	var p tabPartai // Array untuk menyimpan data partai
	var n int       // Jumlah partai unik
	var input int

	// Membaca input suara secara berulang hingga menemukan -1
	for {
		fmt.Scan(&input)
		if input == -1 { // Marker untuk mengakhiri input
			break
		}

		// Mencari posisi partai dalam array
		pos := posisi(p, n, input)
		if pos == -1 { // Jika partai belum ada, tambahkan ke array
			p[n] = Partai{Nama_2311102210: input, Suara: 1}
			n++
		} else { // Jika partai sudah ada, tambahkan suaranya
			p[pos].Suara++
		}
	}

	// Mengurutkan array p dengan insertion sort secara descending
	insertionSort(&p, n)

	// Menampilkan hasil
	for i := 0; i < n; i++ {
		fmt.Printf("%d(%d) ", p[i].Nama_2311102210, p[i].Suara)
	}
	fmt.Println()
}

// Fungsi untuk mencari posisi partai dalam array
func posisi(t tabPartai, n int, nama int) int {
	for i := 0; i < n; i++ {
		if t[i].Nama_2311102210 == nama {
			return i // Mengembalikan indeks partai jika ditemukan
		}
	}
	return -1 // Mengembalikan -1 jika partai tidak ditemukan
}

// Fungsi untuk mengurutkan array partai secara descending berdasarkan jumlah suara
func insertionSort(t *tabPartai, n int) {
	for i := 1; i < n; i++ {
		temp := t[i]
		j := i - 1

		// Geser elemen yang lebih kecil
		for j >= 0 && (t[j].Suara < temp.Suara || (t[j].Suara == temp.Suara && t[j].Nama_2311102210 > temp.Nama_2311102210)) {
			t[j+1] = t[j]
			j--
		}

		t[j+1] = temp
	}
}
