package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// Struct Mahasiswa
type Mahasiswa struct {
	NIM_2311102210   string
	Nama  string
	Nilai int
}

func identitas() {
	fmt.Println("=================================")
	fmt.Println("NIM: 2311102210")
	fmt.Println("Nama:Haposan Felix Marcel Siregar")
	fmt.Println("Kelas: IF-11-06")
	fmt.Println("=================================")
}	

func main() {
	identitas()
	var mahasiswaList []Mahasiswa
	var n int

	// Input jumlah data mahasiswa
	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	fmt.Scan(&n)

	// Input data mahasiswa
	scanner := bufio.NewScanner(os.Stdin)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d (format: NIM_2311102210 Nama Nilai): ", i+1)
		scanner.Scan()
		input := strings.Fields(scanner.Text())

		// Validasi input
		if len(input) != 3 {
			fmt.Println("Error: Format input harus berupa 'NIM_2311102210 Nama Nilai'. Coba lagi.")
			i-- // Ulangi input untuk mahasiswa ini
			continue
		}

		nim := input[0]
		nama := input[1]
		nilai, err := strconv.Atoi(input[2])
		if err != nil {
			fmt.Println("Error: Nilai harus berupa angka. Coba lagi.")
			i-- // Ulangi input untuk mahasiswa ini
			continue
		}

		mahasiswaList = append(mahasiswaList, Mahasiswa{NIM_2311102210: nim, Nama: nama, Nilai: nilai})
	}

	// Input NIM_2311102210 yang akan dicari
	fmt.Print("\nMasukkan NIM_2311102210 mahasiswa yang akan dicari: ")
	scanner.Scan()
	cariNIM := scanner.Text()

	// Pencarian nilai pertama dan nilai terbesar
	nilaiPertama := cariNilaiPertama(mahasiswaList, cariNIM)
	nilaiTerbesar := cariNilaiTerbesar(mahasiswaList, cariNIM)

	// Tampilkan hasil
	if nilaiPertama == -1 {
		fmt.Printf("\nMahasiswa dengan NIM_2311102210 %s tidak ditemukan.\n", cariNIM)
	} else {
		fmt.Printf("\nNilai pertama mahasiswa dengan NIM_2311102210 %s: %d\n", cariNIM, nilaiPertama)
		fmt.Printf("Nilai terbesar mahasiswa dengan NIM_2311102210 %s: %d\n", cariNIM, nilaiTerbesar)
	}
}

// Fungsi mencari nilai pertama berdasarkan NIM_2311102210
func cariNilaiPertama(data []Mahasiswa, nim string) int {
	for _, m := range data {
		if m.NIM_2311102210 == nim {
			return m.Nilai
		}
	}
	return -1 // Jika tidak ditemukan
}

// Fungsi mencari nilai terbesar berdasarkan NIM_2311102210
func cariNilaiTerbesar(data []Mahasiswa, nim string) int {
	maxNilai := -1
	for _, m := range data {
		if m.NIM_2311102210 == nim && m.Nilai > maxNilai {
			maxNilai = m.Nilai
		}
	}
	return maxNilai
}
