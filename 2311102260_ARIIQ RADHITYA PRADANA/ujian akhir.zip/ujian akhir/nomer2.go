package main

import "fmt"

const nMax = 51

type mahasiswa struct {
	NIM   string
	nama  string
	nilai int
}

type arrayMahasiswa [nMax]mahasiswa

// Fungsi untuk menerima masukan sejumlah N data mahasiswa
func inputMahasiswa_2311102260(n int, arr *arrayMahasiswa) {
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data mahasiswa ke-%d:\n", i+1)
		fmt.Print("NIM: ")
		fmt.Scan(&arr[i].NIM)
		fmt.Print("Nama: ")
		fmt.Scan(&arr[i].nama)
		fmt.Print("Nilai: ")
		fmt.Scan(&arr[i].nilai)
	}
}

// Fungsi untuk mencari nilai rata-rata semua mahasiswa dengan NIM tertentu
func rataRataNilai_2311102260(n int, arr arrayMahasiswa, targetNIM string) float64 {
	var totalNilai int
	var jumlah int

	for i := 0; i < n; i++ {
		if arr[i].NIM == targetNIM {
			totalNilai += arr[i].nilai
			jumlah++
		}
	}

	if jumlah == 0 {
		return 0 // Jika tidak ada data untuk NIM tertentu
	}
	return float64(totalNilai) / float64(jumlah)
}

// Fungsi untuk mencari nilai terbesar mahasiswa dengan NIM tertentu
func nilaiTertinggi_2311102260(n int, arr arrayMahasiswa, targetNIM string) int {
	var maxNilai = -1

	for i := 0; i < n; i++ {
		if arr[i].NIM == targetNIM {
			if arr[i].nilai > maxNilai {
				maxNilai = arr[i].nilai
			}
		}
	}

	return maxNilai
}

func main() {
	var n int
	var arr arrayMahasiswa
	var targetNIM string

	fmt.Print("Masukkan jumlah data mahasiswa (N): ")
	fmt.Scan(&n)

	inputMahasiswa_2311102260(n, &arr)

	fmt.Print("Masukkan NIM untuk pencarian: ")
	fmt.Scan(&targetNIM)

	rataRata := rataRataNilai_2311102260(n, arr, targetNIM)
	if rataRata == 0 {
		fmt.Printf("Tidak ditemukan data dengan NIM %s\n", targetNIM)
	} else {
		fmt.Printf("Nilai rata-rata untuk NIM %s: %.2f\n", targetNIM, rataRata)
	}

	nilaiMax := nilaiTertinggi_2311102260(n, arr, targetNIM)
	if nilaiMax == -1 {
		fmt.Printf("Tidak ditemukan data dengan NIM %s\n", targetNIM)
	} else {
		fmt.Printf("Nilai tertinggi untuk NIM %s: %d\n", targetNIM, nilaiMax)
	}
}
