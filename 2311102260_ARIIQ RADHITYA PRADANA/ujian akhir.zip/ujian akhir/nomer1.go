package main

import "fmt"

// Fungsi untuk mengecek apakah elemen sudah ada di dalam set
func exists_2311102260(set []int, n int) bool {
	for _, v := range set {
		if v == n {
			return true
		}
	}
	return false
}

// Fungsi untuk membaca input sebagai himpunan tanpa duplikasi
func inputSet_2311102260() []int {
	var set []int
	var n int

	fmt.Println("Masukkan elemen (akhiri dengan bilangan duplikat atau nilai yang sudah dimasukkan sebelumnya):")
	for {
		fmt.Scan(&n)
		if exists_2311102260(set, n) {
			break
		}
		set = append(set, n)
	}
	return set
}

// Fungsi untuk mencari irisan antara dua himpunan
func findIntersection_2311102260(set1, set2 []int) []int {
	var intersection []int
	for _, v := range set1 {
		if exists_2311102260(set2, v) && !exists_2311102260(intersection, v) {
			intersection = append(intersection, v)
		}
	}
	return intersection
}

// Fungsi untuk mencetak himpunan
func printSet_2311102260(set []int) {
	for _, v := range set {
		fmt.Print(v, " ")
	}
	fmt.Println()
}

func main() {
	fmt.Println("Masukkan elemen untuk himpunan pertama:")
	set1 := inputSet_2311102260()

	fmt.Println("Masukkan elemen untuk himpunan kedua:")
	set2 := inputSet_2311102260()

	intersection := findIntersection_2311102260(set1, set2)

	fmt.Println("Irisan dari kedua himpunan adalah:")
	printSet_2311102260(intersection)
}
